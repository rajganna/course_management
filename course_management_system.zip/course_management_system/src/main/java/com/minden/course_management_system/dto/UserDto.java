package com.minden.course_management_system.dto;

public record UserDto(String studentEmail, String studentName) {
}
