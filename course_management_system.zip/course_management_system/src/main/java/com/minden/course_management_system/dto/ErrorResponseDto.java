package com.minden.course_management_system.dto;

public record ErrorResponseDto(int errorCode, String errorMessage) {
}
