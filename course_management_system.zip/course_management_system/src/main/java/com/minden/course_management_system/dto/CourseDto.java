package com.minden.course_management_system.dto;

public record CourseDto(String studentEmail, String studentName, String courseName) {
}
